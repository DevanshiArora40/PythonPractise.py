# -*- coding: utf-8 -*-
"""
Created on Tue Mar 31 18:48:37 2020

@author: DEVANSHI
"""

try:
    li=[1,2,0,7,-1,-8,3,-7,6,-11]
    a=int(input())
    b=len(li)
    if li[a]<0:
        print("Negative number.")
    elif li[a]==0:
        print("Zero")
    else:
        print("Positive Number.")
except IndexError:
    print("Index is not in the range.")
