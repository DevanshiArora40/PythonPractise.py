# -*- coding: utf-8 -*-
"""
Created on Tue Mar 31 18:38:16 2020

@author: DEVANSHI
"""

try:
    fname = input("Enter file name: ") 
    with open(fname, 'r') as f:
        for line in f:
            l=line.title()
            print(l)
except FileNotFoundError:
    print("File not found.")
