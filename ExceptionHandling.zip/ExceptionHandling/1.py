# -*- coding: utf-8 -*-
"""
Created on Tue Mar 31 18:07:02 2020

@author: DEVANSHI
"""

try:
    a=int(input())
    b=int(input())
    c=a/b
except ZeroDivisionError:
    print("There is a Zero Division Error.")
except SyntaxError:
    print("There is a Syntax Error.")
except NameError:
    print("There is a Name Error.")
except KeyError:
    print("There is a Key Error.")
except IndexError:
    print("There is a Index Error.")
except ImportError:
    print("There is a Import Error.")
except TypeError:
    print("There is a Type Error.")
except ValueError:
    print("There is a Value Error.")
else:
    print("The result is",c)
