# -*- coding: utf-8 -*-
"""
Created on Tue Mar 31 18:19:38 2020

@author: DEVANSHI
"""

try:
    a=int(input())
except ValueError:
    print("The input is not an integer.")
else:
    for i in range(2,a):
        if (a%i==0):
            print("It is not a prime number.")
            break
    else:
        print("It is a prime number.")
