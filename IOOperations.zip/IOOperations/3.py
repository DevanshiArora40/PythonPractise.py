# -*- coding: utf-8 -*-
"""
Created on Tue Mar 31 20:03:50 2020

@author: DEVANSHI
"""

n=input("Enter input to append:")
f1=open('C:\Users\devan\Downloads\IOOperations','a')
f1.write("%s\n"% (n))
f1.close()
f1=open('C:\Users\devan\Downloads\IOOperations')
print(f1.read())
f1.close()
