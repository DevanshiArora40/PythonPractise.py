# -*- coding: utf-8 -*-
"""
Created on Tue Mar 31 20:07:30 2020

@author: DEVANSHI
"""

f1=open('C:\Users\devan\Downloads\IOOperations')
line1=f1.readline()
lis=[]
n=0
while line1!="":
    n=n+1
    lis.append(line1)
    line1=f1.readline()
print("List consisting of each line:",lis)   
f1.close()
