# -*- coding: utf-8 -*-
"""
Created on Tue Mar 31 19:59:06 2020

@author: DEVANSHI
"""

n=int(input("Enter the no. of lines:"))
f1=open('C:\Users\devan\Downloads\IOOperations')
for i in range(0,n):
    line1=f1.readline()
    print("Line %d:"%(i),line1)
f1.close()
