# -*- coding: utf-8 -*-
"""
Created on Tue Mar 31 19:56:21 2020

@author: DEVANSHI
"""

f1=open(
print(f1.read())
f1.close()
