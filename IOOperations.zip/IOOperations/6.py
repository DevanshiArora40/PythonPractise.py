# -*- coding: utf-8 -*-
"""
Created on Tue Mar 31 20:14:38 2020

@author: DEVANSHI
"""

f1=open('C:\Users\devan\Downloads\IOOperations')
wordstring = f1.read()
print("Sentence:\n" + wordstring +"\n")
str1=input("Enter the word:")
wordlist=[]
wordlist = wordstring.split()
print("Frequency:",wordlist.count(str1))
