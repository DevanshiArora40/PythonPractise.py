# -*- coding: utf-8 -*-
"""
Created on Fri Mar 31 20:59:05 2020

@author: DEVANSHI
"""

name=str(input())
dict={"Krishna":[67,68,69],"Arjun":[70,98,63],"Malika":[52,56,60]}
#for name in dict:
if (name=="Krishna"):
    print("Enter a name:",name)
    perc=(67+68+69)/3
    print("Average percentage mark:",int(perc))
elif (name=="Arjun"):
    print("Enter a name:",name)
    perc=(70+98+63)/3
    print("Average percentage mark:",int(perc))
elif (name=="Malika"):
    print("Enter a name:",name)
    perc=(52+56+60)/3
    print("Average percentage mark:",int(perc))
else: 
    print("Student's name not present.")
