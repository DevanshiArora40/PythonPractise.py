# -*- coding: utf-8 -*-
"""
Created on Fri Mar 27 18:24:09 2020

@author: DEVANSHI
"""

set1 = {1,2,3,4,5}
set2 = {4,5,6,7,8}
set3 = set1.union(set2)
print(set3)
