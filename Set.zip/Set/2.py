# -*- coding: utf-8 -*-
"""
Created on Fri Mar 27 18:17:02 2020

@author: DEVANSHI
"""

set1 = {1,2,3,4,5}
set2 = {6,7,8,9,1,4}
set3=set1.intersection(set2)
print(set3)
