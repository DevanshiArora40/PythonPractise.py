# -*- coding: utf-8 -*-
"""
Created on Fri Mar 27 18:25:21 2020

@author: DEVANSHI
"""

set1 = {1,2,4,7,9}
a=min(set1)
b=max(set1)
print(a)
print(b)
