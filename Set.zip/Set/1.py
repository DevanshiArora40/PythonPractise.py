# -*- coding: utf-8 -*-
"""
Created on Fri Mar 27 18:15:01 2020

@author: DEVANSHI
"""

set1 = {1,2,3,4,5}
set1.remove(3)
print(set1)
