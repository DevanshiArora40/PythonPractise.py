# -*- coding: utf-8 -*-
"""
Created on Mon Mar 31 20:06:25 2020

@author: DEVANSHI
"""

import project
name=input()
project.ispalindrome(name)
project.count_the_vowels(name)
project.frequency_of_letters(name)
