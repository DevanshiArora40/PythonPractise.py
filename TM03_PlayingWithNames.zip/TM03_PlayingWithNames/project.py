# -*- coding: utf-8 -*-
"""
Created on Mon Mar 31 18:41:52 2020

@author: DEVANSHI
"""

def ispalindrome(name):
    rev=name[::-1]
    if rev==name:
        print("Yes it is a palindrome.")
    else:
        print("No it is not a palindrome.")
#############################################
def count_the_vowels(name):
    count=0
    vowel=("aeiouAEIOU")
    for i in name:
        if i in vowel:
            count=count+1
    print("No. of vowels:",count)
#############################################
def frequency_of_letters(name):
    yo={}
    for i in name:
        if i in yo:
            yo[i]=yo[i]+1
        else:
            yo[i]=1
    print ("Frequency of letters:",yo)
