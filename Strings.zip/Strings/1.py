# -*- coding: utf-8 -*-
"""
Created on Fri Mar 27 18:58:17 2020

@author: DEVANSHI
"""

string=str(input())
UC = 0
LC = 0
for x in string:
    if x.isupper():
        UC=UC+1        
    elif x.islower():
        LC=LC+1        
print(UC)
print(LC)
