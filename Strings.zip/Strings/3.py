# -*- coding: utf-8 -*-
"""
Created on Fri Mar 27 19:39:47 2020

@author: DEVANSHI
"""

string=str(input())
a=len(string)
b=string[0:2]
print(b*a)
