# -*- coding: utf-8 -*-
"""
Created on Fri Mar 27 20:01:21 2020

@author: DEVANSHI
"""
string=str(input())
a=len(string)
if (string[0]=="x") or (string[-1]=="x"):
    print(string[-(a-1):-1])
else:
    print(string)
