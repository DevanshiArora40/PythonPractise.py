# -*- coding: utf-8 -*-
"""
Created on Fri Mar 27 20:16:47 2020

@author: DEVANSHI
"""

string=str(input())
a=int(input())
for i in string:
    b=string[-a:]
print(b*a)
