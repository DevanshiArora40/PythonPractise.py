# -*- coding: utf-8 -*-
"""
Created on Fri Mar 27 19:12:43 2020

@author: DEVANSHI
"""

string=str(input())
rev=string[::-1]
if(rev==string):
    print("It is a palindrome.")
else:
    print("It is not a palindrome.")
