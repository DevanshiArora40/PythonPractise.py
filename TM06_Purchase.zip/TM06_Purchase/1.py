# -*- coding: utf-8 -*-
"""
Created on Wed Apr  1 09:25:45 2020

@author: DEVANSHI
"""

fname=input("Enter the file name:")
dictionary = {}
with open(fname,'r') as f:
    for line in f:
        try:
            a,b = line.split()
            dictionary[a] = (b)
        except ValueError:
            continue
c=0
t=0
s=0
for k in dictionary:
    if(k!='Discount' and dictionary[k]!='Free'):
        c=c+1
        s=s+int(dictionary[k])
    elif(dictionary[k]=="Free"):
        t=t+1
    else:
        disc=int(dictionary[k])
final=s-disc
print("No of items purchased:",c)
print("No of free items:",t)
print("Amount to pay:",s)  
print("Discount given:",disc)
print("Final Amount paid:",final)
