# -*- coding: utf-8 -*-
"""
Created on Wed Mar 25 17:13:57 2020

@author: DEVANSHI
"""

dic={1:2,3:4,5:6}
sum=0
for i in dic:
    sum=sum+dic[i]
    i=i+1
print(sum)
