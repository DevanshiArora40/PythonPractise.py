# -*- coding: utf-8 -*-
"""
Created on Wed Mar 25 16:54:08 2020

@author: DEVANSHI
"""

dic={1:25, 'car':'bike', 'cristiano':'ronaldo'}
for i in dic:
    print(i)
for i in dic:
    print(dic[i])
for i in dic:
    print(i,dic[i])
