# -*- coding: utf-8 -*-
"""
Created on Wed Mar 25 16:38:07 2020

@author: DEVANSHI
"""
x=int(input())
y=int(input())
dic = {0:10, 1:20}
dic[x]=y
print(dic)
