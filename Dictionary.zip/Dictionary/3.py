# -*- coding: utf-8 -*-
"""
Created on Wed Mar 25 16:49:24 2020

@author: DEVANSHI
"""

dic={1:10,2:20,'drum':'rolls'}
if 1 in dic:
    print("Key exists")
else:
    print("Key does not exist")
