# -*- coding: utf-8 -*-
"""
Created on Wed Mar 25 17:00:06 2020

@author: DEVANSHI
"""
k=1
while(k<16 and k!=0):
    sq=k*k
    dic={k:sq}
    print(dic)
    k=k+1
