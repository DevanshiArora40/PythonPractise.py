# -*- coding: utf-8 -*-
"""
Created on Mon Mar 30 13:45:33 2020

@author: DEVANSHI
"""

def rev(inp):
    reverse=inp[::-1]
    return reverse
inp=str(input())
rev1=rev(inp)
print(rev1)
