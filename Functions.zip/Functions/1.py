# -*- coding: utf-8 -*-
"""
Created on Mon Mar 30 11:53:44 2020

@author: DEVANSHI
"""


def suml(n):
    tot=0
    for i in range(0,n):
        tot=tot+li[i]
    return tot
li=[]
m=int(input())
for i in range(0,m):
    value=int(input())
    li.append(value)
s=suml(m)
print(s)
