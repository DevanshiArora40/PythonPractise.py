# -*- coding: utf-8 -*-
"""
Created on Mon Mar 30 18:21:43 2020

@author: DEVANSHI
"""

def prime(n):
    f=0
    for i in range(2,n):
        if n%i==0:
            f=f+1
    if f==0:
            print("The number is prime.")
    else:
            print("The number is not prime.")
inp=int(input())
prime(inp)
