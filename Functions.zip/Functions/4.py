# -*- coding: utf-8 -*-
"""
Created on Mon Mar 30 14:38:50 2020

@author: DEVANSHI
"""

def stringcase(s):
    UC=0
    LC=0
    b=len(s)
    for i in range(0,b):
        if (s[i].isupper()==True):
            UC=UC+1
        elif(s[i].islower()==True):
            LC=LC+1
    return UC,LC
s=input()
a=stringcase(s)
print(a)
