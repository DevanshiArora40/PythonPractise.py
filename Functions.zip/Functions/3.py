# -*- coding: utf-8 -*-
"""
Created on Mon Mar 30 13:52:10 2020

@author: DEVANSHI
"""

def fact(num):
    fac=1
    if num>0:
        for i in range(1,num+1,1):
            fac=fac*i
        return fac
    elif num==0:
        return 1
a=int(input())
b=fact(a)
print(b)
