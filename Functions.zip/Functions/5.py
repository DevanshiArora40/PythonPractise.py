# -*- coding: utf-8 -*-
"""
Created on Mon Mar 30 17:44:22 2020

@author: DEVANSHI
"""

def even(li):
    print("Even values present are:")
    for i in li:
        if(i%2==0):
            print(i)
li=[]
a=int(input())
for j in range(0,a):
    val=int(input())
    li.append(val)
even(li)
