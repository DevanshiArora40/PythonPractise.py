# -*- coding: utf-8 -*-
"""
Created on Fri Mar 31 20:37:14 2020

@author: DEVANSHI
"""

list1=[2,3,6,6,5]
list2=[]
for x in list1:
    if x not in list2:
        list2.append(x)
winner=max(list2)
list2.remove(winner)
runnerup=max(list2)
print(runnerup)
