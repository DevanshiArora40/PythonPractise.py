# -*- coding: utf-8 -*-
"""
Created on Sun Mar 31 19:53:04 2020

@author: DEVANSHI
"""

dict={"Jeff":"Is afraid of Dogs.","David":"Plays the piano.","Jason":"Can fly an airplane."}
dict["Jeff"]="Is afraid of heights."
dict["Jill"]="Can hula dance."
for i in dict:
    print(i,":",dict[i])
