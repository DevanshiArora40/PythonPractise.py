# -*- coding: utf-8 -*-
"""
Created on Wed Apr  1 09:27:13 2020

@author: DEVANSHI
"""

f1=open('C:\Users\devan\Downloads\TM05_FindTheSecret')
line1=f1.readline()
lis=[]
n=0
while line1!="":
    n=n+1
    lis.append(line1)
    line1=f1.readline()
c=len(lis)
if(c>0 and c<12):
    print("Meeting Time : %dAM"%(c))
elif(c==12):
    print("Meeting Time : %dPM"%(c))
elif(c==24):
    print("Meeting Time : %dAM"%(c-12))
else:
    print("Meeting Time : %dPM"%(c-12))
f1.close()

f1=open('C:\Users\devan\Downloads\TM05_FindTheSecret')
wordstring = f1.read()
str_list = wordstring.split()  
unique_words = set(str_list) 
lst=[]
for words in unique_words : 
    lst.append(str_list.count(words))
for words in unique_words:
    if(max(lst)==str_list.count(words)):
        str1=words
print("Meeting Place: %s Street"%(str1))
f1.close()
