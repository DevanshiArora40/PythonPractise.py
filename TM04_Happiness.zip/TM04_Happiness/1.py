# -*- coding: utf-8 -*-
"""
Created on Tue Mar 31 16:25:49 2020

@author: DEVANSHI
"""

import sys
n=len(sys.argv)
lst=[]
print("Total Arguments passed:",n)
print("Arguments Passed:",end=" ")
for i in range(1,n):
    print(sys.argv[i],end=" ")
    lst.append([n for n in sys.argv[i].split('-')])  
c=0
for i in range(0,len(lst[0])):
    for j in range(0,len(lst[2])):
        if(lst[0][i]==lst[2][j]):
            c=c+1
s=0
for i in range(0,len(lst[1])):
    for j in range(0,len(lst[2])):
        if(lst[1][i]==lst[2][j]):
            s=s+1
t=c-s
print("\nFinal Happiness is:",t)
