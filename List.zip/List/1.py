# -*- coding: utf-8 -*-
"""
Created on Mon Mar 23 18:28:50 2020

@author: DEVANSHI
"""

list = [1,2,3,4,5]
for i in list:
    print (i)
