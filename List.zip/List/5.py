# -*- coding: utf-8 -*-
"""
Created on Mon Mar 23 18:51:02 2020

@author: DEVANSHI
"""

list1=[1,2,3]
list2=[4,5,6]
list=list1+list2
print(list)
