# -*- coding: utf-8 -*-
"""
Created on Mon Mar 23 18:57:16 2020

@author: DEVANSHI
"""

list = [1, 2, 3]
list.insert(1, 0)
print (list)
