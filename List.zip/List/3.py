# -*- coding: utf-8 -*-
"""
Created on Mon Mar 23 18:33:36 2020

@author: DEVANSHI
"""

list = [1,2,3,4,5]
list1=list.reverse()
print(list)
