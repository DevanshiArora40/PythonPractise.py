# -*- coding: utf-8 -*-
"""
Created on Mon Mar 23 20:42:37 2020

@author: DEVANSHI
"""

list = [1,2,3,1,2,3]
list.remove(1)
print(list)
