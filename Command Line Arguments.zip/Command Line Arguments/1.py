# -*- coding: utf-8 -*-
"""
Created on Tue Mar 31 15:55:54 2020

@author: DEVANSHI
"""

import sys

a = int(sys.argv[1])
b = int(sys.argv[2])

print(a + b)
