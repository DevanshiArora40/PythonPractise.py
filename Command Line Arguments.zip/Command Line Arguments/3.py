# -*- coding: utf-8 -*-
"""
Created on Tue Mar 31 16:13:39 2020

@author: DEVANSHI
"""

import sys
li = []
def sop(num):
    for i in range(2,num):
        if(num%i==0):
            return False
    return True
for i in range(2,11):
    li.append(int(sys.argv[i]))
sum=0
for i in li:
    if(sop(i)):
        sum=sum+i
print(sum)
