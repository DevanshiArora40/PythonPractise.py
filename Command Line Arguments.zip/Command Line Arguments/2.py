# -*- coding: utf-8 -*-
"""
Created on Tue Mar 31 16:09:09 2020

@author: DEVANSHI
"""

import sys
inp=str(sys.argv[1])
progname=(sys.argv[2])
print(inp, progname)
