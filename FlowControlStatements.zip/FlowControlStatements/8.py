# -*- coding: utf-8 -*-
"""
Created on Mon Mar 23 09:05:03 2020

@author: DEVANSHI
"""

num = int(input())
sum=0
while(num!=0):
    ld=num%10
    sum=sum+ld
    num=num//10
print(sum)
