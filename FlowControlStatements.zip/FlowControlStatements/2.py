# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
num = float(input())
if (num%2==0):
    print("Even Number");
elif (num%2==1):
    print("Odd Number");
