# -*- coding: utf-8 -*-
"""
Created on Sun Mar 22 19:43:53 2020

@author: DEVANSHI
"""

num = int(input(" "))
if num > 1:
   for i in range(2,num):
       if (num % i) == 0:
           print("Not a prime number")
           break
   else:
       print("Prime number")
else:
   print("Not a prime number")
