# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
num = float(input())
if num>0:
    print("Positive Number");
elif num<0:
    print("Negative Number");
elif num==0:
    print("Zero")
