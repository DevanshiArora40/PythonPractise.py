# -*- coding: utf-8 -*-
"""
Created on Mon Mar 23 09:34:42 2020

@author: DEVANSHI
"""

num = int(input())
num1=num
rev=0
while(num!=0):
    ld=num%10
    rev=rev*10+ld
    num=num//10
if(rev==num1):
    print(num1,"is a palindrome.")
else:
    print(num1,"is not a palindrome.")
