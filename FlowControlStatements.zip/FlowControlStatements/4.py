# -*- coding: utf-8 -*-
"""
Created on Sun Mar 22 19:01:52 2020

@author: DEVANSHI
"""

for num in range(1,11):
    print(num, end = "\t")
