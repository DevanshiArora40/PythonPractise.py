# -*- coding: utf-8 -*-
"""
Created on Mon Mar 23 09:28:58 2020

@author: DEVANSHI
"""

num = int(input())
rev=0
while(num!=0):
    ld=num%10
    rev=rev*10+ld
    num=num//10
print(rev)
