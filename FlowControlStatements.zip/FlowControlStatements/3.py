# -*- coding: utf-8 -*-
"""
Created on Sun Mar 22 18:53:22 2020

@author: DEVANSHI
"""

num1 = int(input())
num2 = int(input())
d1=num1%10
d2=num2%10
if (d1==d2):
    print("true")
else: 
    print("false")
