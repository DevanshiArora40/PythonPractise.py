# -*- coding: utf-8 -*-
"""
Created on Sun Mar 22 20:06:14 2020

@author: DEVANSHI
"""

for num in range (10,100):
    if num>1:
        for i in range (2,num):
            if (num%i)==0:
                break
        else:
            print(num)
