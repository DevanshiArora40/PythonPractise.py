# -*- coding: utf-8 -*-
"""
Created on Sun Mar 22 19:14:22 2020

@author: DEVANSHI
"""

for num in range (23,58):
    if (num%2==0):
        print(num)
