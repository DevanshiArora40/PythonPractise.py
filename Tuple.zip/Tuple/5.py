# -*- coding: utf-8 -*-
"""
Created on Wed Mar 25 18:45:41 2020

@author: DEVANSHI
"""


list = [(10, 20, 40), (40, 50, 60), (70, 80, 90)]
print([tuple[:-1] + (100,) for tuple in list])
