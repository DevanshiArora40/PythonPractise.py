# -*- coding: utf-8 -*-
"""
Created on Wed Mar 25 18:39:26 2020

@author: DEVANSHI
"""

list = [1,2,3,4,5]
tup=tuple(list)
print(tup)
