# -*- coding: utf-8 -*-
"""
Created on Wed Mar 25 18:37:24 2020

@author: DEVANSHI
"""

tup=(1,2,3,4,5)
if 2 in tup:
    print("Element exists")
else:
    print("Element does not exist")
