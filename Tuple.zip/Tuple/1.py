# -*- coding: utf-8 -*-
"""
Created on Wed Mar 25 18:35:22 2020

@author: DEVANSHI
"""

tup=(1,2,3,4,5,6,7,8,9)
print(tup[3])
print(tup[-4])
