# -*- coding: utf-8 -*-
"""
Created on Wed Mar 25 18:41:00 2020

@author: DEVANSHI
"""

tuple=(1,2,3,4,5)
a=tuple.index(3)
print(a)
